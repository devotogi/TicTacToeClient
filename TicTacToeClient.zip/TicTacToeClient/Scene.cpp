#include "pch.h"
#include "Scene.h"
#include "Wnd.h"
void Scene::Init(Wnd* _wnd)
{

}

void Scene::Update(Wnd* _wnd)
{

}

void Scene::Render(Wnd* _wnd)
{

#ifdef _DEBUG

# else 

#endif

}

void Scene::MouseClickEvent(int x, int y)
{
}
